# ReelTogether Android

Android WebView wrapper for the supplied ReelTogether HTML experience.

## Features
- Packages `app/src/main/assets/index.html` inside the APK.
- Supports JavaScript and DOM storage.
- Provides Android file selection for the movie and subtitle inputs.
- Requests Android camera and microphone permissions for the page's WebRTC video call.
- Uses a secure HTTPS base origin for WebRTC APIs.
- Requires internet for PeerJS signaling, STUN, and the page's externally loaded PeerJS library.

## Build in Termux with Termux Studio

This project uses Android SDK 36 and application ID `com.ashu.reeltogether`.

After cloning this repository in Termux:

```sh
studio build ~/ReelTogether :app:assembleDebug
```

If your project folder is different, replace `~/ReelTogether` with that path.

The debug APK should be at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Copy it to Downloads:

```sh
mkdir -p ~/storage/downloads
cp app/build/outputs/apk/debug/app-debug.apk ~/storage/downloads/ReelTogether.apk
```

Run the copy command from the project directory. If Termux storage has not been configured, run `termux-setup-storage` and grant permission first.

## Important behavior / limitations
- This is a wrapper around the provided HTML, not a rewrite of its room/signaling backend.
- Both participants still need the same playable video file locally; the HTML synchronizes playback controls but does not stream the movie to the other participant.
- Room signaling and calls depend on PeerJS/network availability. Some networks may block peer-to-peer media connections.
- Video call support depends on the Android System WebView version and camera/microphone permissions.
- The app needs internet access. It is not an offline movie-room app.

## Uploading to GitHub
Upload the contents of this project directory (the `settings.gradle`, `build.gradle`, `gradle.properties`, `app/`, and `README.md` files) to the root of a GitHub repository. Do not upload build output folders or local SDK files.
